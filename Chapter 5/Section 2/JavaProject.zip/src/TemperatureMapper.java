/*
 * This program is based on a program
 * that calculates the maximum closing price of stocks 
 * The original program is available at
 * https://www.hadoopinrealworld.com/
 */

//map program
import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TemperatureMapper extends Mapper<LongWritable, Text, Text, FloatWritable>
{
	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException
	{
		// one line (record)
		String record = value.toString(); 
		
		// split one record into three fields: [airport code, date, temperature]
		String[] fields = record.split(","); 
		
		// retrieve airport code from the first column
		String airport = fields[0]; 
		
		// retrieve temperature from the third column
		Float temperature = Float.parseFloat(fields[2]);
		
		//output a (key, value) pair: (airport, temperature)
		context.write(new Text(airport), new FloatWritable(temperature));
	}
}