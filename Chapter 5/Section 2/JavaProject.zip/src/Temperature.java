/*
 * This program is based on a program
 * that calculates the maximum closing price of stocks 
 * The original program is available at
 * https://www.hadoopinrealworld.com/
 */

//control program
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class Temperature
{
	public static void main(String[] args) throws Exception
	{
		if (args.length != 2)
		{
			System.err.println("Please use this command format: Temperature <input path> <output path>");
			System.exit(-1);
		}

		Job myjob = new Job();
		myjob.setJarByClass(Temperature.class);
		myjob.setJobName("AverageTemperature");

		FileInputFormat.addInputPath(myjob, new Path(args[0]));
		FileOutputFormat.setOutputPath(myjob, new Path(args[1]));
		
	    myjob.setInputFormatClass(TextInputFormat.class);
	    myjob.setOutputFormatClass(TextOutputFormat.class);

		myjob.setMapperClass(TemperatureMapper.class);
		myjob.setReducerClass(TemperatureReducer.class);

		myjob.setOutputKeyClass(Text.class);
		myjob.setOutputValueClass(FloatWritable.class);

		System.exit(myjob.waitForCompletion(true) ? 0 : 1);
	}
}
